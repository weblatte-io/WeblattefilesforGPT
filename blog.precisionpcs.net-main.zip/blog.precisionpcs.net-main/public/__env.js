
window.__env = {
  ADMIN_PIN_1: "%ADMIN_PIN_1%",
  ADMIN_PIN_2: "%ADMIN_PIN_2%",
  ADMIN_PIN_3: "%ADMIN_PIN_3%",
  ADMIN_PIN_4: "%ADMIN_PIN_4%",
  ADMIN_PIN_5: "%ADMIN_PIN_5%"
};
